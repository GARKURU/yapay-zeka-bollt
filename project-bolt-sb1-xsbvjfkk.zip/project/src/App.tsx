import React, { useState, useRef, useEffect } from 'react';
import { Send, Bot, User, Loader2 } from 'lucide-react';

interface Message {
  role: 'assistant' | 'user';
  content: string;
}

function App() {
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim()) return;

    const userMessage = { role: 'user', content: input };
    setMessages(prev => [...prev, userMessage]);
    setInput('');
    setIsLoading(true);

    try {
      const response = await fetch('https://api-inference.huggingface.co/models/gpt2', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${import.meta.env.VITE_HUGGINGFACE_API_KEY_WRITING}`
        },
        body: JSON.stringify({
          inputs: input,
          parameters: {
            max_length: 100,
            temperature: 0.7,
            top_p: 0.9,
          }
        })
      });

      if (!response.ok) {
        throw new Error('Failed to get response from Hugging Face API');
      }

      const data = await response.json();
      const aiMessage = {
        role: 'assistant',
        content: data[0]?.generated_text || 'Sorry, I could not generate a response.'
      };

      setMessages(prev => [...prev, aiMessage]);
    } catch (error) {
      const errorMessage = {
        role: 'assistant',
        content: 'Sorry, I encountered an error. Please try again.'
      };
      setMessages(prev => [...prev, errorMessage]);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gray-100 flex flex-col">
      <header className="bg-white shadow-sm">
        <div className="max-w-4xl mx-auto px-4 py-4">
          <div className="flex items-center gap-2">
            <Bot className="w-6 h-6 text-blue-600" />
            <h1 className="text-xl font-semibold text-gray-900">AI Assistant</h1>
          </div>
        </div>
      </header>

      <main className="flex-1 max-w-4xl w-full mx-auto px-4 py-8 flex flex-col">
        <div className="flex-1 bg-white rounded-lg shadow-md mb-4 p-4 overflow-y-auto max-h-[60vh]">
          {messages.length === 0 ? (
            <div className="text-center text-gray-500 my-8">
              Start a conversation by typing a message below.
            </div>
          ) : (
            <div className="space-y-4">
              {messages.map((message, index) => (
                <div
                  key={index}
                  className={`flex items-start gap-3 ${
                    message.role === 'assistant' ? 'bg-gray-50' : ''
                  } p-3 rounded-lg transition-all duration-300 ease-in-out`}
                >
                  {message.role === 'assistant' ? (
                    <Bot className="w-6 h-6 text-blue-600 mt-1" />
                  ) : (
                    <User className="w-6 h-6 text-gray-600 mt-1" />
                  )}
                  <div className="flex-1">
                    <div className="font-medium text-sm text-gray-900 mb-1">
                      {message.role === 'assistant' ? 'AI Assistant' : 'You'}
                    </div>
                    <div className="text-gray-700">{message.content}</div>
                  </div>
                </div>
              ))}
              {isLoading && (
                <div className="flex items-start gap-3 bg-gray-50 p-3 rounded-lg animate-fade-in">
                  <Bot className="w-6 h-6 text-blue-600 mt-1" />
                  <div className="flex-1">
                    <div className="font-medium text-sm text-gray-900 mb-1">
                      AI Assistant
                    </div>
                    <div className="flex items-center gap-2 text-gray-700">
                      <Loader2 className="w-4 h-4 animate-spin" />
                      Thinking...
                    </div>
                  </div>
                </div>
              )}
              <div ref={messagesEndRef} />
            </div>
          )}
        </div>

        <form onSubmit={handleSubmit} className="flex gap-2">
          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder="Type your message..."
            className="flex-1 rounded-lg border border-gray-300 px-4 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          />
          <button
            type="submit"
            disabled={!input.trim() || isLoading}
            className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 disabled:opacity-50 disabled:cursor-not-allowed flex items-center gap-2 transition-colors duration-200"
          >
            <Send className="w-4 h-4" />
            Send
          </button>
        </form>
      </main>
    </div>
  );
}

export default App;